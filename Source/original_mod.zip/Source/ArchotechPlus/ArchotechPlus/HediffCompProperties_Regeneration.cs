﻿using Verse;

namespace ArchotechPlus
{
    public class HediffCompProperties_Regeneration : HediffCompProperties
    {
        public HediffCompProperties_Regeneration()
        {
            compClass = typeof (HediffComp_Regeneration);
        }
    }
}