﻿using Verse;

namespace ArchotechPlus
{
    public class CompProperties_FollowsTarget : CompProperties
    {
        public CompProperties_FollowsTarget()
        {
            compClass = typeof (CompFollowsTarget);
        }
        
    }
}