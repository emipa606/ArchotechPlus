﻿using System.Collections.Generic;
using Verse;

namespace ArchotechPlus
{
    public class CompProperties_Resurrector : CompProperties
    {
        public CompProperties_Resurrector()
        {
            compClass = typeof (CompResurrector);
        }
    }
}